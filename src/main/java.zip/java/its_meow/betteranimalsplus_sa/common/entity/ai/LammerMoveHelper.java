package its_meow.betteranimalsplus_sa.common.entity.ai;

import java.util.Random;

import its_meow.betteranimalsplus_sa.common.entity.EntityLammergeier;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;

public class LammerMoveHelper extends EntityMoveHelper {
    private final EntityLammergeier parentEntity;

    public LammerMoveHelper(EntityLammergeier lam) {
        super(lam);
        this.parentEntity = lam;
    }

    @Override
    public boolean isUpdating() {
        return this.action == EntityMoveHelper.Action.MOVE_TO;
    }

    @Override
    public void onUpdateMoveHelper() {
        if (this.action == EntityMoveHelper.Action.MOVE_TO) {
            double d0 = this.posX - this.parentEntity.posX;
            double d1 = this.posY - this.parentEntity.posY;
            double d2 = this.posZ - this.parentEntity.posZ;
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            if (d3 <= 1.0D || d3 >= 16384.0D || this.posY > 500.0D) {
                this.action = EntityMoveHelper.Action.WAIT;
            }
            d3 = MathHelper.sqrt(d3);
            if (this.isNotColliding(this.posX, this.posY, this.posZ, d3)) {
                this.parentEntity.motionX += d0 / d3 * 0.1D;
                this.parentEntity.motionY += d1 / d3 * 0.1D + (this.parentEntity.getAttackTarget() == null ? 0.0D : this.parentEntity.getAttackTarget().isRidingOrBeingRiddenBy(this.parentEntity) ? 0.1D : 0D);
                this.parentEntity.motionZ += d2 / d3 * 0.1D;
            } else {
                this.parentEntity.motionY += 0.05;
                if (this.parentEntity.getEntityWorld().getBlockState(this.parentEntity.getPosition().up()).isFullBlock()) {
                    this.parentEntity.motionX += d0 / d3 * 0.1D;
                    this.parentEntity.motionY -= 0.05 + (this.parentEntity.getAttackTarget() == null ? 0.0D : this.parentEntity.getAttackTarget().isRidingOrBeingRiddenBy(this.parentEntity) ? 0.1D : 0D);
                    this.parentEntity.motionZ += d2 / d3 * 0.1D;
                }
                if (this.parentEntity.posX == this.parentEntity.lastTickPosX && this.parentEntity.posY == this.parentEntity.lastTickPosY && this.parentEntity.posZ == this.parentEntity.lastTickPosZ) {
                    Random rand = this.parentEntity.getRNG();

                    this.setMoveTo(this.parentEntity.posX + rand.nextInt(2) - 1, this.parentEntity.posY + rand.nextInt(2) - 1, this.parentEntity.posZ + rand.nextInt(2) - 1, 0.5D);
                }
                this.action = EntityMoveHelper.Action.WAIT;
            }
        }
    }

    /**
     * Checks if entity bounding box is not colliding with terrain
     */
    private boolean isNotColliding(double x, double y, double z, double p_179926_7_) {
        double d0 = (x - this.parentEntity.posX) / p_179926_7_;
        double d1 = (y - this.parentEntity.posY) / p_179926_7_;
        double d2 = (z - this.parentEntity.posZ) / p_179926_7_;
        AxisAlignedBB axisalignedbb = this.parentEntity.getEntityBoundingBox();

        for (int i = 1; i < p_179926_7_; ++i) {
            axisalignedbb = axisalignedbb.offset(d0, d1, d2);

            if (!this.parentEntity.world.getCollisionBoxes(this.parentEntity, axisalignedbb).isEmpty()) {
                return false;
            }
        }

        return true;
    }
}